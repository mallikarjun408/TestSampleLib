package com.coop.cardactivationwidget.utils

class MyErrorMessage {
    var code : String? =null
    var message: String? = null
    var error: String? =null
    var title:String? =null
    var description:String? =null

}