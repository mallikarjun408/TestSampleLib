package com.coop.cardactivationwidget.cardactivation.model

import com.google.gson.annotations.SerializedName

class ErrorModel {

    @SerializedName("detailMessage")
    var status: String ? = null
}