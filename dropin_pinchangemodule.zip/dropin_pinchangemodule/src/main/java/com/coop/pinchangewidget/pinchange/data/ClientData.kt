package com.coop.pinchangewidget.pinchange.data
import java.io.Serializable

class ClientData : Serializable {
    var clientUrl: String? = null
    var client_id: String? = null
    var client_secret: String? = null
    var panNumber:String? = null
}