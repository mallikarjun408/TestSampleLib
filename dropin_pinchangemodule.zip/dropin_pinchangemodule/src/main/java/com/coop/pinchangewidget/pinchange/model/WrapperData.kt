package com.coop.pinchangewidget.pinchange.model

import com.google.gson.annotations.SerializedName

class WrapperData {
    @SerializedName("wrappedKey")
    var wrappedKey: String? = null

}